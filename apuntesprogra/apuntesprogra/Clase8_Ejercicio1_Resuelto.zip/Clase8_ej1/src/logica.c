/*
 * logica.c
 *
 *  Created on: Apr 18, 2020
 *      Author: Mauro
 */

#include <stdio.h>
#include <stdlib.h>
#include "utn.h"

